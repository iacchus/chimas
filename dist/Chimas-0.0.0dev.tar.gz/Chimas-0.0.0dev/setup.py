from distutils.core import setup

setup(
    name='Chimas',
    version='0.0.0dev',
    packages=['chimas',],
    license='General Public License v. 3'
)
